
public interface IMoveValidation {
	public boolean isValidMove(Point p0, Point p1);
}
